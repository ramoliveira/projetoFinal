#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "ui.h"

void cabecalho(char texto[TAM_TEXTO]) {
	int i;
	CSE
	for (i = 1; i <= (strlen(texto) + 2); i++) {
		HOR
	}
	CSD
	VEE
	printf(" %s ", texto); 
	VED
	CIE
	for (i = 1; i <= (strlen(texto) + 2); i++) {
		HOR
	}
	CID
} 
