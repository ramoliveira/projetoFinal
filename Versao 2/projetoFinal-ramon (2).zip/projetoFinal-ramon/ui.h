#ifndef _UI_h
#define _UI_h

#define TAM_TEXTO 80
#define CSE printf("\xC9");
#define HOR printf("\xCD");
#define CSD printf("\xBB\n");
#define VEE printf("\xBA");
#define VED printf("\xBA\n");
#define CIE printf("\xC8");
#define CID printf("\xBC\n");

void cabecalho(char texto[TAM_TEXTO]);
#endif
